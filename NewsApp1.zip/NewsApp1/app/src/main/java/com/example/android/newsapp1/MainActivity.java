package com.example.android.newsapp1;

import android.app.LoaderManager;
import android.content.Intent;
import android.content.Loader;
import android.net.Uri;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Toast;


import com.example.android.newsapp1.NewsFeedGuardianEdition;

import java.util.List;


public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<ContentFeed>>, SwipeRefreshLayout.OnRefreshListener {


    private static final int LOADER_ID = 0;

    NewsAdapter baseAdapter;

    SwipeRefreshLayout swipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swipe = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);
        swipe.setOnRefreshListener(this);
        swipe.setColorSchemeColors(getResources().getColor(R.color.colorAccent));

        ExpandableListHeight listview = (ExpandableListHeight) findViewById(R.id.listview);

        baseAdapter = new NewsAdapter(MainActivity.this);

        listview.setAdapter(baseAdapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent contentBrowser = new Intent("android.intent.action.VIEW", Uri.parse(baseAdapter.getItem(position).getWebUrl()));
                startActivity(contentBrowser);
            }
        });

        if (Connectivity.isNetworkAvailable(MainActivity.this)) {
            getSupportLoaderManager().initLoader(LOADER_ID, null, this);
        } else {
            Toast.makeText(MainActivity.this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRefresh() {
        if (Connectivity.isNetworkAvailable(MainActivity.this)) {
            getSupportLoaderManager().restartLoader(LOADER_ID, null, this);
        } else {
            Toast.makeText(MainActivity.this, getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            swipe.setRefreshing(false);
        }
    }

    @Override
    public Loader<List<ContentFeed>> onCreateLoader(int id, Bundle args) {
        return new NewsFeedGuardianEdition (this);
    }

    @Override
    public void onLoadFinished(Loader<List<ContentFeed>> loader, List<ContentFeed> data) {
        swipe.setRefreshing(false);
        if (null != data) {
            baseAdapter.clear();
            baseAdapter.addFeeds(data);
            baseAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onLoaderReset(Loader<List<ContentFeed>> loader) {

    }
}


