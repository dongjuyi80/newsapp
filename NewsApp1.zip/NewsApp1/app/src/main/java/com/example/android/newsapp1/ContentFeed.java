package com.example.android.newsapp1;

class ContentFeed {private String sectionName;
    private String webTitle;
    private String webPublicationDate;
    private String webUrl;

    public ContentFeed(String sectionName, String webTitle, String webUrl, String webPublicationDate) {

        this.setSectionName(sectionName);
        this.setWebTitle(webTitle);
        this.setWebUrl(webUrl);
        this.setWebPublicationDate(webPublicationDate);
    }
    public String getSectionName () {
        return sectionName;
    }
    private void setSectionName (String sectionName){
        this.sectionName = sectionName;
    }

    public String getWebTitle () {
        return webTitle;
    }

    private void setWebTitle (String webTitle){
        this.webTitle = webTitle;
    }

    public String getWebUrl () {
        return webUrl;
    }

    private void setWebUrl (String webUrl){
        this.webUrl = webUrl;
    }

    public String getWebPublicationDate () {
        return webPublicationDate;

    }

    private void setWebPublicationDate (String webPublicationDate){
        this.webPublicationDate = webPublicationDate;
    }


}


